<?php
$servidor = 'localhost';
$usuario  = 'root';
$senha 	  = '';
$banco 	  = 'psymed';
$conexao  = mysqli_connect($servidor, $usuario, $senha, $banco);

?>